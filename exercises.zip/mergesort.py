#!/usr/bin/env python2.7


def merge_sort(array, n):
    sorted_array = []

    while True:
        if n == 1:
            print sorted_array
            break
        else:
            halves = divmod(len(array), 2)
            l1 = array[:halves[0]]
            l2 = array[halves[0]:]

        sorted_array.append(merge_sort(l1))
        sorted_array.append()

if __name__ == '__main__':
    merge_sort([4, 2, 8, 9, 7, 10, 45], 8)
